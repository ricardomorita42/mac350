Nome: Ricado Mikio Morita
NUSP: 5412562

	Incluido neste está o arquivo EP2_5412562_BUILD.sql, o qual executa o arquivo DDL,
seguido das funções CRUD e, por fim, o arquivo DML. Recomenda-se usar este arquivo build
pois o arquivo DML usa as funções CRUD para popular as tabelas.

	Sobre os exemplos de funções, como o arquivo DML se usar do CRUD para popular as
tabelas, recomenda-se que use-se este arquivo para vê-las em ação.

	Também foi incluido a pasta scripts, as quais contêm scripts python que foram
usados para criação dos usuários do sistema.
